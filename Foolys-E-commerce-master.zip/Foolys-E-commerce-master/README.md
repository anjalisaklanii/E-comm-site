# Foolys-E-commerce
E-commerce website created on MERN using React js ,React Redux-toolkit , Node js , Express js, MongoDB ,Tailwind CSS , MUI ,FORMIK/YUP  authentication

Download this project 
steps to run package :

 1) npm install in client folder 
 2) npm install in main server folder 
 3) nodemon app.js in server folder 
 4) npm start in client folder


home page
![image](https://user-images.githubusercontent.com/108664361/192994960-5bd7bde5-122e-47e5-9b71-1ec30af976f7.png)
login page 
![image](https://user-images.githubusercontent.com/108664361/192995144-ec2e5e8f-e67b-4966-8dc8-c45078339cef.png)
sign up page 
![image](https://user-images.githubusercontent.com/108664361/192995229-5dd81377-c9b7-4f5c-ad6e-357545fff345.png)

catalogue
![image](https://user-images.githubusercontent.com/108664361/192995391-bd23fd79-0844-483f-85dd-9a2a37f87f4e.png)
product detail 
![image](https://user-images.githubusercontent.com/108664361/192996452-8d47dac0-4f76-4849-9e44-eb19eb870f47.png)

cart page
![image](https://user-images.githubusercontent.com/108664361/192996218-76d98e13-fd47-44d1-8bc2-450ae336d30d.png)
